package io.github.dissonantau.bleatkan.instance

/**
 * Represents the Instance Version for compatibility and features
 *
 * Expects a String with one dot and an option letter
 * E.g.
 * * 2.0
 * * 2.1a
 * * 2.2c
 *
 *
 */
class InstanceVersion(version: String) : Comparable<InstanceVersion> {
    val major: Int

    val minor: Int

    val patch: Char?

    init {
        require(version.isNotBlank()) { "Version is Blank" }

        val temp = version.split('.')

        require(temp.count() <= 2) { "Version has more than 2 parts split by a dot" }

        //Convert 1st section to Int
        major = temp[0].toInt()


        if (temp[1].length > 1 && temp[1][temp[1].length - 1].isLetter()) {
            // More than one Char, and last Char is Letter

            // Patch is last Char
            patch = temp[1][temp[1].length - 1]

            // Minor is characters except
            minor = (temp[1].substring(0, temp[1].length - 1)).toInt()
        } else {
            // Only one Char

            // Minor is characters except
            minor = temp[1].toInt()

            // Patch is null
            patch = null
        }

    }

    /**
     * Compares this object with the specified object for order. Returns zero if this object is equal
     * to the specified [other] object, a negative number if it's less than [other], or a positive number
     * if it's greater than [other].
     */
    override fun compareTo(other: InstanceVersion): Int {
        if (this === other) return 0

        if (this.major == other.major) {
            if (this.minor == other.minor) {
                if (this.patch == other.patch) {
                    // same, could be same letter or null
                    return 0
                } else {

                    when {
                        (this.patch == null) -> {
                            // this is null, other isn't null with prior == check
                            // this = 2.1 - other is 2.1a - this is lower
                            return -1
                        }

                        (other.patch == null) -> {
                            // other is null, this isn't null with prior == check
                            // this = 2.1a - other is 2.1 - this is higher
                            return 1
                        }

                        else -> {
                            //Both have values, return char compare
                            return this.patch.compareTo(other.patch)
                        }

                    }
                }
            } else return this.minor - other.minor
        } else return this.major - other.major

    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        //if (other == null) return false
        if (javaClass != other?.javaClass) return false

        other as InstanceVersion

        if (major != other.major) return false
        if (minor != other.minor) return false
        if (patch != other.patch) return false

        return true
    }

    override fun hashCode(): Int {
        var result = major
        result = 31 * result + minor
        result = 31 * result + (patch?.hashCode() ?: 0)
        return result
    }

    override fun toString(): String {
        return "$major.$minor${patch ?: ""}"
    }

}